import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const distPath = path.join(__dirname, 'dist');
const assetsPath = path.join(__dirname, 'assets');

app.use('/assets', express.static(path.join(distPath, 'assets'), { maxAge: '1d' }));
app.use('/assets', express.static(assetsPath, { maxAge: '1d' }));

app.use(express.static(distPath, { maxAge: '1d' }));

app.all('/assets/*', (req, res) => {
  res.status(404).send('Asset not found');
});

/** Prefer prerendered dist/<route>/index.html so crawlers see route-specific SEO without JS. */
app.get('*', (req, res) => {
  const pathname = (req.path || '/').replace(/\/+$/, '') || '/';

  if (pathname !== '/') {
    const prerendered = path.join(distPath, ...pathname.slice(1).split('/'), 'index.html');
    if (fs.existsSync(prerendered)) {
      return res.sendFile(prerendered);
    }
  }

  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Nowazone-web server running on port ${PORT}`);
});
